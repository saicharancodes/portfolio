# input = ["eat","tea","tan","ate","nat","bat"]
# store = {}
# output = []
# for el in input:
#     clean = "".join(sorted(el))
#     if clean in store:
#         temp = store[clean]
#         temp.append(el)
#         store[clean] = temp
#     else:
#         store[clean] = [el]
# for el in store.values():
#     output.append(el)
# print(output)

print(sorted([1,5,3]))